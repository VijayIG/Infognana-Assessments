from django.db import models
 
# Create your models here.
class tour(models.Model):
    Your_name = models.CharField(max_length=30)
    No_Of_Days = models.IntegerField()
    No_of_passengers = models.IntegerField()
    created_at=models.DateTimeField(verbose_name="Departure")
    updated_at=models.DateTimeField(verbose_name="Return")